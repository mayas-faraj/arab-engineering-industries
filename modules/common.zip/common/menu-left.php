<?
function availableForm($formName){
	$thisUserId = getCurrentUserId();
	if($thisUserId=="") checkCurrentUser();
	if(!authentication($formName) && $formName != "login")
		return false;
	else
		return true;
	}

?>


<table width="200" border="0" align="center" cellpadding="0" cellspacing="10" id="menu">
<tr>
  <td>
  	<div class="title">Site Settings</div>
	<?if(availableForm('listMenus')){?>
	<div style="padding-left:10px;"><a href="../menus/listMenus.php"><?=Menus?></a></div>
	<?}if(availableForm('listPages')){?>
	<div style="padding-left:10px;"><a href="../pages/listPages.php"><?=Text?></a></div>
	<?}if(availableForm('listQuery_forms')){?>
	<div style="padding-left:10px;"><a href="../qforms/listQuery_forms.php"><?=Forms?></a></div>
	<?}if(availableForm('seo')){?>
	<div style="padding-left:10px;"><a href="../common/seo.php?filename=" class="dialog-form">SEO Default settings</a></div>
	<?}if(availableForm('listGalleries')){?>
	<div style="padding-left:10px;"><a href="../galleries/listGalleries.php"><?=Galleries?></a></div>
	<?}if(availableForm('listResources')){?>
	<div style="padding-left:10px;"><a href="../resources/listResources.php"><?=Resources?></a></div>
	<?}?>
	<!--div style="padding-left:10px;"><a href="../cms/listModules.php"><?=Modules?></a></div-->
	</td>
</tr>
<tr>
  <td>
  	<div class="title">AFEI</div>
	<?if(availableForm('listNews')){?>
	<div style="padding-left:10px;"><a href="../news/listNews.php">Announcements & News</a></div>
	<?}if(availableForm('listMembers')){?>
	<div style="padding-left:10px;"><a href="../members/listMembers.php">UnionMembers</a></div>
	<?}if(availableForm('listCouncilMembers')){?>
	<div style="padding-left:10px;"><a href="../council/listCouncilMembers.php">BOD</a></div>
	<?}if(availableForm('listcomittees')){?>
	<div style="padding-left:10px;"><a href="../committees/listcomittees.php">Committees</a></div>
	<?}if(availableForm('listActivities')){?>
	<div style="padding-left:10px;"><a href="../Activities/listActivities.php">Activities</a></div>
	<?}?>
	</td>
</tr>
<tr>
  <td>
  	<div class="title">General Settings</div>
	<?if(availableForm('fields')){?>
	<div style="padding-left:10px;"><a href="../setting/fields.php">Activity Fields</a></div>
	<?}if(availableForm('levels')){?>
	<div style="padding-left:10px;"><a href="../setting/levels.php">Activity Levels</a></div>
	<?}if(availableForm('types')){?>
	<div style="padding-left:10px;"><a href="../setting/types.php">Activity Types</a></div>
	<?}if(availableForm('specialization')){?>
	<div style="padding-left:10px;"><a href="../setting/specialization.php">Specialization</a></div>
	<?}if(availableForm('terms')){?>
	<div style="padding-left:10px;"><a href="../setting/terms.php">Terms</a></div>
	<?}?>
	</td>
</tr>
<tr>
  <td>
  	<div class="title">Users</div>
	<?if(availableForm('listUsers')){?>
	<div style="padding-left:10px;"><a href="../users/listUsers.php">User</a></div>
	<?}if(availableForm('listUsers_groups')){?>
	<div style="padding-left:10px;"><a href="../users/listUsers_groups.php">Users Groups</a></div>
	<?}?>
	<div style="padding-left:10px;"><a href="../login/logout.php">Logout</a></div>
	</td>
</tr>
</table>