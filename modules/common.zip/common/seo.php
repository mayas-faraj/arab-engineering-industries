<?php include_once("headerpopup.php"); ?>
<style>
.input1{
	border:1px #CCC solid;
	width:350px;
}.input2{
	border:1px #CCC solid;
	width:350px;
	height:80px;
}
</style>
<?
$filename = addslashes($_REQUEST['filename']);
$sub = $_REQUEST['sub'];
if($sub){
	$id = addslashes($_REQUEST['id']);
	$title = addslashes($_REQUEST['title']);
	$keywords = addslashes($_REQUEST['keywords']);
	$description = addslashes($_REQUEST['description']);

	$SQL = "INSERT INTO seo (filename , title , keywords , description ) VALUES ('$filename' , '$title' , '$keywords' , '$description' )";
	$result = mysql_query($SQL);
	if($result)
 		echo Record_Enter;
	else{
		$SQL = "UPDATE seo SET title = '$title' , keywords = '$keywords' , description = '$description' WHERE filename = '$filename' ";
		$result = mysql_query($SQL);
		echo Record_Update;
	}
}//Sub
if((!$sub) || (!$result)){
	$sql ="SELECT * FROM seo WHERE filename = '$filename' ";
	$result = MYSQL_QUERY($sql);
	$numberOfRows = MYSQL_NUMROWS($result);
	if ($numberOfRows>0) {
		$i=0;
		$id= MYSQL_RESULT($result,$i,"id");
		$filename= MYSQL_RESULT($result,$i,"filename");
		$title= MYSQL_RESULT($result,$i,"title");
		$keywords= MYSQL_RESULT($result,$i,"keywords");
		$description= MYSQL_RESULT($result,$i,"description");
	}?>
    <div id="output">
    <form name="seoForm" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" enctype="multipart/form-data">
    <input type="Hidden" name="sub" size="20" value="save" />
    <input type="Hidden" name="id" size="20" value="<?php echo $id?>" class=""/>
    <input type="Hidden" name="filename" size="20" value="<?php echo stripslashes($filename)?>" />
    <table align="center">
    
    <tr><td align="<?php echo _ALI?>"><b><?php echo Title?>:</b></td><td width="5"></td>
    <td><input type="Text" name="title" size="60" value="<?php echo stripslashes($title)?>" class="input1"/></td></tr>
    
    <tr><td align="<?php echo _ALI?>"><b><?php echo Keywords?>:</b></td><td width="5"></td>
    <td><textarea name="keywords" cols="60" rows="4" class="input2" ><?php echo stripslashes($keywords)?></textarea></td></tr>
    
    <tr><td align="<?php echo _ALI?>"><b><?php echo Description?>:</b></td><td width="5"></td>
    <td><textarea name="description" cols="60" rows="4"  class="input2"><?php echo stripslashes($description)?></textarea></td></tr>
    
    </table>
    </form>
    </div>
<?php 
} ?>
<?php include_once("footerpopup.php"); ?>